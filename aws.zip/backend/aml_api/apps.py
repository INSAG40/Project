from django.apps import AppConfig


class AmlApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aml_api'
